<?php

declare(strict_types=1);

namespace In2code\Powermail\Utility;

use TYPO3\CMS\Core\Mail\MailerInterface;
use TYPO3\CMS\Core\Mail\MailMessage;
use TYPO3\CMS\Core\Utility\GeneralUtility;

/**
 * Class MailUtility
 * @codeCoverageIgnore
 */
class MailUtility
{
    /**
     * Send a plain mail for simple notifies
     *
     * @param string $receiverEmail Email address to send to
     * @param string $senderEmail Email address from sender
     * @param string $subject Subject line
     * @param string $body Message content
     * @return bool mail was sent?
     */
    public static function sendPlainMail(
        string $receiverEmail,
        string $senderEmail,
        string $subject,
        string $body
    ): bool {
        $message = GeneralUtility::makeInstance(MailMessage::class);
        $message->setTo([$receiverEmail => '']);
        $message->setFrom([$senderEmail => 'Sender']);
        $message->setSubject($subject);
        $message->text($body);
        try {
            self::getMailer()->send($message);
            return true;
        } catch (\Exception $e) {
            return false;
        }
    }

    private static function getMailer(): MailerInterface
    {
        return GeneralUtility::makeInstance(MailerInterface::class);
    }
}
