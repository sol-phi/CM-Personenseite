<?php

declare(strict_types=1);
namespace In2code\Powermail\Update;

use Doctrine\DBAL\DBALException;
use In2code\Powermail\Domain\Model\Field;
use In2code\Powermail\Domain\Model\Page;
use In2code\Powermail\Exception\DatabaseFieldMissingException;
use In2code\Powermail\Utility\DatabaseUtility;
use Throwable;
use TYPO3\CMS\Core\Attribute\UpgradeWizard;
use TYPO3\CMS\Core\Upgrades\DatabaseUpdatedPrerequisite;
use TYPO3\CMS\Core\Upgrades\UpgradeWizardInterface;

/**
 * Class PowermailRelationUpdateWizard
 * to copy values of
 * - tx_powermail_domain_model_field.pages to .page and
 * - tx_powermail_domain_model_pages.forms to .form
 */
#[UpgradeWizard('powermailRelationUpdateWizard')]
class PowermailRelationUpdateWizard implements UpgradeWizardInterface
{
    public function getIdentifier(): string
    {
        return 'powermailRelationUpdateWizard';
    }

    public function getTitle(): string
    {
        return 'Powermail: Update relations in database (relevant for entries from < 8.0.0)';
    }

    /**
     * Return the description for this wizard
     */
    public function getDescription(): string
    {
        return 'Basicly this upgrade wizard copies values from tx_powermail_domain_model_field.pages to .page and ' .
            'tx_powermail_domain_model_pages.forms to .form with two simple queries';
    }

    public function executeUpdate(): bool
    {
        try {
            $connection = DatabaseUtility::getConnectionForTable(Field::TABLE_NAME);
            $connection->executeQuery('update ' . Field::TABLE_NAME . ' set page=pages;');
            $connection = DatabaseUtility::getConnectionForTable(Page::TABLE_NAME);
            $connection->executeQuery('update ' . Page::TABLE_NAME . ' set form=forms;');
        } catch (Throwable) {
            return false;
        }

        return true;
    }

    /**
     * @throws DBALException
     * @throws DatabaseFieldMissingException
     */
    public function updateNecessary(): bool
    {
        return $this->areOldFieldsExistingAndFilled() && $this->areNewFieldsEmpty();
    }

    /**
     * @return string[]
     */
    public function getPrerequisites(): array
    {
        return [
            DatabaseUpdatedPrerequisite::class,
        ];
    }

    /**
     * @throws DBALException
     */
    protected function areOldFieldsExistingAndFilled(): bool
    {
        return DatabaseUtility::isFieldFilled('pages', Field::TABLE_NAME)
            && DatabaseUtility::isFieldFilled('forms', Page::TABLE_NAME);
    }

    /**
     * @throws DBALException
     * @throws DatabaseFieldMissingException
     */
    protected function areNewFieldsEmpty(): bool
    {
        if (DatabaseUtility::isFieldExistingInTable('page', Field::TABLE_NAME) === false) {
            throw new DatabaseFieldMissingException(
                'Field tx_powermail_domain_model_field.page is missing. Did you forget a database compare?',
                1580560323
            );
        }

        if (DatabaseUtility::isFieldExistingInTable('form', Page::TABLE_NAME) === false) {
            throw new DatabaseFieldMissingException(
                'Field tx_powermail_domain_model_page.form is missing. Did you forget a database compare?',
                1580560354
            );
        }

        return DatabaseUtility::isFieldFilled('page', Field::TABLE_NAME) === false &&
            DatabaseUtility::isFieldFilled('form', Page::TABLE_NAME) === false;
    }
}
